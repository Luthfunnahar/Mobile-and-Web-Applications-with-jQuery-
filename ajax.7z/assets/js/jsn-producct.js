$(function () {
// Globals variables
// 	An array containing objects with information about the products.
	var products = [];


// These are called on page load
// Get data about our products from products.json.
	$.getJSON( "ajax/products.json", function( data ) {

		// Write the data into our global variable.
		products = data;

		// Call a function to create HTML for all the products.
		generateAllProductsHTML(products);

		// Manually trigger a hashchange to start the app.
		$(window).trigger('hashchange');
	});


// An event handler with calls the render function on every hashchange.
// The render function will show the appropriate content of out page.
	$(window).on('hashchange', function(){
		render(decodeURI(window.location.hash));
	});


// Navigation all the product
	function render(url) {

		// Get the keyword from the url.
		var temp = url.split('/')[0];

		var	map = {
			// The "Homepage".
			'': function() {
				// show all the products
				renderProductsPage(products);
			},

			// Single Products page.
			'#product': function() {
				// Get the index of which product we want to show and call the appropriate function.
				var index = url.split('#product/')[1].trim();
				renderSingleProductPage(index, products);
			},
		};

		// Execute the needed function depending on the url keyword (stored in temp).
		if(map[temp]){
			map[temp]();
		}
	}


// This function is called only once - on page load.
// It fills up the products list via a handlebars template.
// It recieves one parameter - the data we took from products.json.
	function generateAllProductsHTML(data){

		var list = $('.all-products .products-list');

		var theTemplateScript = $("#products-template").html();
		//Compile the template​
		var theTemplate = Handlebars.compile (theTemplateScript);
		list.append (theTemplate(data));


		// Each products has a data-index attribute.
		// On click change the url hash to open up a preview for this product only.
		// Remember: every hashchange triggers the render function.
		list.find('li').on('click', function (e) {
			e.preventDefault();

			var productIndex = $(this).data('index');
			window.location.hash = 'product/' + productIndex;
		})
	}


// This function receives an object containing all the product we want to show.
	function renderProductsPage(data){

		var page = $('.all-products'),
			allProducts = $('.all-products .products-list > li');
		// Show the page itself.
		// (the render function hides all pages so we need to show the one we want).
		page.addClass('visible');
	}


// Opens up a preview for one of the products.
// Its parameters are an index from the hash and the products object.
	function renderSingleProductPage(index, data){

		var page = $('.single-product'),
			container = $('.preview-large');

		// Find the wanted product by iterating the data object and searching for the chosen index.
		if(data.length){
			data.forEach(function (item) {
				if(item.id == index){
					// Populate '.preview-large' with the chosen product's data.
					container.find('h3').text(item.name);
					container.find('img').attr('src', item.image.large);
					container.find('p').text(item.description);
				}
			});
		}

		// Show the page.
		page.addClass('visible');

	}




});