// JavaScript Document

/*============================
  Back Button script 
============================*/

function goBack() {
    window.history.back();
}


/*============================
  Parse Data from XML file 
============================*/
	//standard jQuery ajax technique to load an xml file

	//is this working at all
		console.log ("starting...");
	
	//standard JQuery ajax techniquie to load an XML file
		//var xml;
		$(document).ready(function(){
				
            $.ajax({
				type:"GET",
				url: "ajax/phoneData.xml",
				dataType:"xml",
				success: xmlParser
				});
        });
		
	//loading XML file and parsing....
	//this function is the callbacck specified in line 24 above..
	
		function xmlParser(data){
			xml = data;
			
			$(xml).find("phones").each(function(){
				var phones = $(this);
				var name = $(phones).find("name").text(); 
				var id = $(phones).find("id").text(); 
                var src = $(phones).find("url").text();   
				
				//console.log(name);
				//$("#mylist").append('<li><a href="' + (src) + '" class="ui-btn ui-btn-icon-right ui-icon-carat-r">' + name + '</a></li>');
				
				$("#mylist").append('<li><a href="' + (src) + '" class="ui-btn ui-btn-icon-right ui-icon-carat-r" target="_blank">' + name + '</a></li>');
				
				
				});
				$("#mylist").listview('refresh');
			}
		 
		 
/*============================
  Get JSON data 
============================*/
$(document).ready(function(){
	$.getJSON("ajax/birdydata.json", function(data){
		var bird_data ='';
		$.each(data,function(key,value){
			bird_data += '<tr>';
			bird_data += '<td>' + value.nm + '</td>';
			bird_data += '<td>' + value.sci + '</td>';
			bird_data += '<td>' + value.grp + '</td>';
			bird_data += '</tr>';
		});
		$('#birdTable').append(bird_data);
	});
});

